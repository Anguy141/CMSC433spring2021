package cmsc433.p3;

import java.util.List;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.concurrent.RecursiveTask;
import java.util.concurrent.Callable;
import java.util.concurrent.ForkJoinPool;

import cmsc433.p3.SkippingMazeSolver.SolutionFound;

public class StudentMTMazeSolverFork extends SkippingMazeSolver {
	public StudentMTMazeSolverFork(Maze maze) {
		super(maze);

	}

	@Override
	public List<Direction> solve() {
		ForkJoinPool forkJoinPool = new ForkJoinPool(4);
		return forkJoinPool.invoke(new myDFSMazeSolverFork());
	}

	public class myDFSMazeSolverFork extends RecursiveTask<List<Direction>> {
		private static final long serialVersionUID = 1L;



		public myDFSMazeSolverFork() {
		}

		public List<Direction> compute() {
				Choice startC;
				Choice endC;
				myDFSMazeSolver forkArr[] = null;
				List<Direction> listOfSteps = null;
				try {
					startC = firstChoice(maze.getStart());
					endC = firstChoice(maze.getEnd());
					int totalChoices = startC.choices.size() + endC.choices.size();				
					forkArr = new myDFSMazeSolver[totalChoices];
					
					for(int i = 0; i < totalChoices; i++) {
						if (!startC.choices.isEmpty()) {
							Choice ch = follow(startC.at, startC.choices.peek());
							Direction initDir = startC.choices.pop();
							forkArr[i] = new myDFSMazeSolver(initDir, ch);
						} else {
							Choice ch = follow(endC.at, endC.choices.peek());
							Direction initDir = endC.choices.pop();
							forkArr[i] = new myDFSMazeSolver(initDir, ch);
						}
					}
				} catch (SolutionFound e) {
					e.printStackTrace();
				}
				for (int i = 0; i < forkArr.length/2; i++) {
					for (int j = forkArr.length/2; j < forkArr.length-1; j++) {
						forkArr[i].fork();
						List<Direction> temp = forkArr[j].compute();
						if ((listOfSteps = forkArr[i].join()) != null) {
							break;
						} else if (temp != null) {
							listOfSteps = temp;
							break;
						}		
					}
				}				
				return listOfSteps;
			}
		}
	
	
	public class myDFSMazeSolver extends RecursiveTask<List<Direction>> {
		private static final long serialVersionUID = 1L;
		Direction dir;
		Choice start;
		
		public myDFSMazeSolver(Direction dir, Choice start) {
			this.dir = dir;
			this.start = start; 
		}

		public List<Direction> compute() {
			LinkedList<Choice> choiceStack = new LinkedList<Choice>();
			Choice ch;

			try {
				choiceStack.push(start);
				while (!choiceStack.isEmpty()) {
					ch = choiceStack.peek();
					if (ch.isDeadend()) {
						// backtrack.
						choiceStack.pop();
						if (!choiceStack.isEmpty())
							choiceStack.peek().choices.pop();
						continue;
					}
					choiceStack.push(follow(ch.at, ch.choices.peek()));
				}
				// No solution found.
				return null;
			} catch (SolutionFound e) {
				Iterator<Choice> iter = choiceStack.iterator();
				LinkedList<Direction> solutionPath = new LinkedList<Direction>();
				while (iter.hasNext()) {
					ch = iter.next();
					solutionPath.push(ch.choices.peek());
				}
				
				// pushes the initial direction to the stack
				solutionPath.push(dir);

				if (maze.display != null)
					maze.display.updateDisplay();
				return pathToFullPath(solutionPath);
			}
		}
	}
}
